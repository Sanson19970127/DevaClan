using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using Conductor.Extensions;
using Conductor.TrackedValues;
using Conductor.UI;
using TrainworksReloaded.Core;
using TrainworksReloaded.Core.Extensions;
using TrainworksReloaded.Core.Interfaces;
using TrainworksReloaded.Base;
using TrainworksReloaded.Base.Extensions;
using UnityEngine;
using UnityEngine.UI;

namespace DevaClan
{
    [HarmonyPatch(typeof(CardManager), nameof(CardManager.OnCharacterKilled))]
    static class DeathMemory
    {
        static void Prefix(CharacterState killedUnit, ICoreGameManagers coreGameManagers)
        {
            if (killedUnit.GetTeamType() != Team.Type.Monsters) return;
            BattleMemory.Remember(killedUnit);
            var card = killedUnit.GetSpawnerCard();
            if (card != null && !killedUnit.HasStatusEffect("cardless")) BattleMemory.Active.Dead.Add(card);
            if (Plugin.IsConstruct(killedUnit) && Plugin.Has(coreGameManagers, "ChargeRecycler")) Plugin.Gain(coreGameManagers, 1);
        }
    }
    [HarmonyPatch(typeof(CardManager), nameof(CardManager.ReturnUnitCardToHand))]
    static class ReturnMemory
    {
        static void Prefix(CharacterState character) => BattleMemory.Remember(character);
    }
    [HarmonyPatch(typeof(CharacterState), nameof(CharacterState.OnSpawn))]
    static class SpawnMemory
    {
        static IEnumerator Postfix(IEnumerator result, CharacterState __instance, AllGameManagers ___allGameManagers)
        {
            var g = ___allGameManagers.GetCoreManagers();
            if (__instance.GetTeamType() == Team.Type.Monsters && Plugin.KarmaId != null)
            {
                var card = __instance.GetSpawnerCard();
                if (card != null && BattleMemory.Active.Karma.TryGetValue(card, out int n) && n > 0) __instance.AddStatusEffect(Plugin.KarmaId, n, (CharacterState)null, allowModification: false);
            }
            TemporaryMemory.Restore(__instance);
            while (result.MoveNext()) yield return result.Current;
            BalanceRules.AfterSummon(__instance, g);
        }
    }
}
