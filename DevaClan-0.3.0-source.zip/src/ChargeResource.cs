using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using Conductor.Extensions;
using Conductor.TrackedValues;
using Conductor.UI;
using TrainworksReloaded.Core;
using TrainworksReloaded.Core.Extensions;
using TrainworksReloaded.Core.Interfaces;
using TrainworksReloaded.Base;
using TrainworksReloaded.Base.Extensions;
using UnityEngine;
using UnityEngine.UI;

namespace DevaClan
{
    public sealed class ChargeHud : ClassMechanicHud
    {
        public override void Refresh(SaveManager saveManager, PlayerManager playerManager, CardManager cardManager)
        {
            // Replays suppress count animations. Rebind the visible number to
            // the authoritative resource when the game refreshes its HUD.
            if (Plugin.Charge != null) ShowCount(Plugin.Charge.GetCurrentValue());
        }
        protected override void HandleValueChanged(TrackedValueChangedParams changedParams)
        {
            if (changedParams.entryDuration != CardStatistics.EntryDuration.ThisTurn) return;
            if (SaveManager.IsInUndoModeStatic) ShowCount(changedParams.value);
            else base.HandleValueChanged(changedParams);
        }
    }
    public sealed class ChargeResource : SimpleGlobalTrackedValueHandler
    {
        // Current-turn storage deliberately persists across turns, but resets between battles.
        public override void UpdateStatsForNextTurn() { }
        public override void UpdateStatsForFirstTurn() { Reset(); }
        public override void Reset() { base.Reset(); BattleMemory.Clear(); }
        public override void OnCombatPreviewEnabled() { base.OnCombatPreviewEnabled(); BattleMemory.BeginPreview(); }
        public override void OnCombatPreviewDisabled() { base.OnCombatPreviewDisabled(); BattleMemory.EndPreview(); }
    }

}
