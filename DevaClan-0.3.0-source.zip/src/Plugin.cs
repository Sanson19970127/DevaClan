using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using Conductor.Extensions;
using Conductor.TrackedValues;
using Conductor.UI;
using TrainworksReloaded.Core;
using TrainworksReloaded.Core.Extensions;
using TrainworksReloaded.Core.Interfaces;
using TrainworksReloaded.Base;
using TrainworksReloaded.Base.Extensions;
using UnityEngine;
using UnityEngine.UI;

namespace DevaClan
{
    [BepInPlugin(Guid, "Deva Clan / 天人氏族", "0.3.0")]
    [BepInDependency("TrainworksReloaded.Plugin")]
    [BepInDependency("Conductor")]
    public sealed class Plugin : BaseUnityPlugin
    {
        public const string Guid = "sanson.DevaClan";
        internal static ManualLogSource Log;
        internal static ChargeResource Charge;
        internal static ConstructSummonResource ConstructSummons;
        internal static CardStatistics.TrackedValueType ConstructSummonStat;
        internal static CardStatistics.TrackedValueType ChargeStat;
        internal static readonly Dictionary<string, CardData> Cards = new Dictionary<string, CardData>();
        internal static readonly Dictionary<string, CharacterData> Units = new Dictionary<string, CharacterData>();
        internal static readonly Dictionary<string, CardUpgradeData> Upgrades = new Dictionary<string, CardUpgradeData>();
        internal static readonly Dictionary<string, RelicData> Relics = new Dictionary<string, RelicData>();
        internal static readonly Dictionary<string, CharacterTriggerData> Triggers = new Dictionary<string, CharacterTriggerData>();
        internal static SubtypeData Construct;
        internal static string KarmaId;
        internal static CharacterTriggerData.Trigger ResetTrigger;
        public void Awake()
        {
            Log = Logger;
            var root = Path.GetDirectoryName(Info.Location);
            var files = Directory.GetFiles(Path.Combine(root, "json"), "*.json", SearchOption.AllDirectories)
                .Select(p => p.Substring(root.Length + 1).Replace('\\', '/')).OrderBy(p => p, StringComparer.Ordinal).ToArray();
            if (files.Length == 0) throw new InvalidOperationException("DevaClan content JSON is missing; install the complete package.");
            if (files.Length > 1 && files.Any(p => string.Equals(p, "json/content.json", StringComparison.OrdinalIgnoreCase)))
                throw new InvalidOperationException("Old json/content.json and modular JSON coexist. Back up and replace the complete DevaClan folder, or run Install.cmd.");
            Railhead.GetBuilder().Configure(Guid, c => c.AddMergedJsonFile(files.ToList()));
            Railend.ConfigurePostAction(c =>
            {
                var cards = c.GetInstance<IRegister<CardData>>();
                foreach (string id in ContentIds.Cards) Cards[id] = cards.GetValueOrDefault(Guid.GetId(TemplateConstants.Card, id));
                var units = c.GetInstance<IRegister<CharacterData>>();
                foreach (string id in ContentIds.Units) Units[id] = units.GetValueOrDefault(Guid.GetId(TemplateConstants.Character, id));
                var upgrades = c.GetInstance<IRegister<CardUpgradeData>>();
                foreach (string id in ContentIds.Upgrades) Upgrades[id] = upgrades.GetValueOrDefault(Guid.GetId(TemplateConstants.Upgrade, id));
                var relics = c.GetInstance<IRegister<RelicData>>();
                foreach (string id in ContentIds.Relics) Relics[id] = relics.GetValueOrDefault(Guid.GetId(TemplateConstants.RelicData, id));
                var triggers = c.GetInstance<IRegister<CharacterTriggerData>>();
                foreach (string id in ContentIds.Triggers) Triggers[id] = triggers.GetValueOrDefault(Guid.GetId(TemplateConstants.CharacterTrigger, id));
                Construct = c.GetInstance<IRegister<SubtypeData>>().GetValueOrDefault(Guid.GetId(TemplateConstants.Subtype, "Construct"));
                KarmaId = c.GetInstance<IRegister<StatusEffectData>>().GetValueOrDefault(Guid.GetId(TemplateConstants.StatusEffect, "karmergy")).GetStatusId();
                ChargeStat = c.GetInstance<IRegister<CardStatistics.TrackedValueType>>().GetValueOrDefault(Guid.GetId(TemplateConstants.TrackedValueTypeEnum, "Charge"));
                ResetTrigger = c.GetInstance<IRegister<CharacterTriggerData.Trigger>>().GetValueOrDefault(Guid.GetId(TemplateConstants.CharacterTriggerEnum, "OnReset"));
                ConstructSummonStat = c.GetInstance<IRegister<CardStatistics.TrackedValueType>>().GetValueOrDefault(Guid.GetId(TemplateConstants.TrackedValueTypeEnum, "ConstructSummons"));
                ConstructSummons = new ConstructSummonResource();
                ConstructSummonStat.SetTrackedValueHandler(ConstructSummons);
                Charge = new ChargeResource();
                ChargeStat.SetTrackedValueHandler(Charge);
                HudManager.GetHUD(Guid, "ChargeHud")?.SetTrackedValueHandler(Charge);
                int missing = Cards.Count(k => k.Value == null) + Units.Count(k => k.Value == null) + Upgrades.Count(k => k.Value == null) + Relics.Count(k => k.Value == null) + Triggers.Count(k => k.Value == null);
                Log.LogInfo($"DEVA VALIDATION: {Cards.Count} cards, {Units.Count} units, {Relics.Count} relics; missing registrations={missing}.");
                if (missing != 0) Log.LogError("Deva content registration incomplete.");
                Log.LogInfo($"DEVA LOCALIZATION: initialized translation storage for {LocalizationCompatibility.RepairedTerms} terms.");
            });
            new Harmony(Guid).PatchAll();
            Log.LogInfo("Deva Clan 0.3.0 loaded; balance update candidate.");
        }
        internal static bool Has(ICoreGameManagers g, string id) => g != null && Relics.TryGetValue(id, out var data) && data != null && g.GetSaveManager().GetAllRelics().Any(r => r.GetRelicDataID() == data.GetID());
        internal static bool Is(CharacterState c, string id) => c != null && Units.TryGetValue(id, out var d) && c.GetSourceCharacterData() == d;
        internal static bool Is(CardState c, string id) => c != null && Cards.TryGetValue(id, out var d) && c.GetCardDataID() == d.GetID();
        internal static bool IsConstruct(CharacterState c) => c != null && Construct != null && c.GetHasSubtype(Construct);
        internal static bool IsConstruct(CardState c) => c?.GetSpawnCharacterData()?.GetSubtypes()?.Contains(Construct) == true;
        internal static int Level(CharacterState c, string path)
        {
            if (c == null) return 0;
            // Champion path upgrades live on the spawning card. They are not
            // necessarily present in the character's later applied-upgrade list.
            var card = c.GetSpawnerCard();
            for (int i = 3; i > 0; --i)
                if (Upgrades.TryGetValue(path + i, out var d) && (card?.HasUpgrade(d) == true || c.HasUpgrade(d))) return i;
            return 0;
        }
        internal static List<CharacterState> Floor(RoomState room, Team.Type team = Team.Type.Monsters)
        {
            var list = new List<CharacterState>();
            if (room != null) room.AddCharactersToList(list, team);
            return list.Where(c => c != null && c.IsAlive && !c.IsDestroyed).ToList();
        }
        internal static void Gain(ICoreGameManagers g, int n, CardState card = null)
        {
            if (Charge != null)
            {
                g.GetCardStatistics().IncrementStat(card, ChargeStat, n);
                if (!g.GetSaveManager().PreviewMode && !SaveManager.IsInUndoModeStatic)
                {
                    g.GetMonsterManager().RefreshCharacterAbilityUI();
                    var rooms = g.GetRoomManager();
                    var ui = rooms.GetRoomUI();
                    if (ui != null && rooms.IsValidRoomIndex(rooms.GetSelectedRoom()))
                        ui.RefreshTrainRoomAttachmentDisplay(rooms.GetRoom(rooms.GetSelectedRoom()));
                }
            }
        }
    }

}
