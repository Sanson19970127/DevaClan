using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using Conductor.Extensions;
using Conductor.TrackedValues;
using Conductor.UI;
using TrainworksReloaded.Core;
using TrainworksReloaded.Core.Extensions;
using TrainworksReloaded.Core.Interfaces;
using TrainworksReloaded.Base;
using TrainworksReloaded.Base.Extensions;
using UnityEngine;
using UnityEngine.UI;

namespace DevaClan
{
    internal sealed class Memory
    {
        public Dictionary<CardState,int> Karma = new Dictionary<CardState,int>();
        public Dictionary<CardState,int> Discounts = new Dictionary<CardState,int>();
        public HashSet<CardState> Dead = new HashSet<CardState>();
        public int Abilities;
        public HashSet<int> RetainKarmergyFloors = new HashSet<int>();
        public HashSet<int> Relentless = new HashSet<int>();
        public Dictionary<CardState,CardState> GiantOwners = new Dictionary<CardState,CardState>();
        public HashSet<CharacterState> Stasis = new HashSet<CharacterState>();
        public Dictionary<CharacterState,int> TurnSilence = new Dictionary<CharacterState,int>();
        public HashSet<CardState> TemporaryCards = new HashSet<CardState>();
        public HashSet<CharacterState> TemporaryUnits = new HashSet<CharacterState>();
        public Memory Clone() => new Memory { Karma = new Dictionary<CardState,int>(Karma), Discounts = new Dictionary<CardState,int>(Discounts), Dead = new HashSet<CardState>(Dead), Abilities = Abilities, RetainKarmergyFloors = new HashSet<int>(RetainKarmergyFloors), Relentless = new HashSet<int>(Relentless), GiantOwners = new Dictionary<CardState,CardState>(GiantOwners), Stasis = new HashSet<CharacterState>(Stasis), TurnSilence = new Dictionary<CharacterState,int>(TurnSilence), TemporaryCards = new HashSet<CardState>(TemporaryCards), TemporaryUnits = new HashSet<CharacterState>(TemporaryUnits) };
    }
    internal static class BattleMemory
    {
        static Memory actual = new Memory(), preview = new Memory();
        static bool isPreview;
        internal static Memory Active => isPreview ? preview : actual;
        internal static void Clear() { actual = new Memory(); preview = new Memory(); isPreview = false; }
        internal static void BeginPreview() { preview = actual.Clone(); isPreview = true; }
        internal static void EndPreview() { preview = actual.Clone(); isPreview = false; }
        internal static void Remember(CharacterState unit)
        {
            TemporaryMemory.Remember(unit);
            var card = unit?.GetSpawnerCard();
            if (card != null && Plugin.KarmaId != null) Active.Karma[card] = unit.GetStatusEffectStacks(Plugin.KarmaId);
        }
    }

}
