using System.Collections;
using System.Collections.Generic;
using Conductor.TrackedValues;

namespace DevaClan
{
    public sealed class CardEffectRetainFloorKarmergy : DevaEffectBase
    {
        public override IEnumerator ApplyEffect(CardEffectState e, CardEffectParams p, ICoreGameManagers g, ISystemManagers sys)
        {
            var room = Room(p, g);
            if (room != null) BattleMemory.Active.RetainKarmergyFloors.Add(room.GetRoomIndex());
            yield break;
        }
    }

    // Use the framework's battle resource for preview/undo serialization.
    // Count every friendly Construct, even before acquiring the relic.
    public sealed class ConstructSummonResource : SimpleGlobalTrackedValueHandler
    {
        public override void UpdateStatsForNextTurn() { }
        public override void UpdateStatsForFirstTurn() { Reset(); }
    }

    internal static class BalanceRules
    {
        internal static int RetainedKarmergy(int stacks, bool friendly, int liberation, bool feast) =>
            !friendly ? 0 : feast || liberation == 3 ? stacks : liberation > 0 ? stacks / 2 : 0;
        internal static int ConstructAttackBonus(int summonCount) => summonCount * 2;
        internal static HashSet<int> ConsumeFeast()
        {
            var floors = new HashSet<int>(BattleMemory.Active.RetainKarmergyFloors);
            BattleMemory.Active.RetainKarmergyFloors.Clear();
            return floors;
        }
        internal static void AfterSummon(CharacterState unit, ICoreGameManagers g)
        {
            if (unit == null || unit.GetTeamType() != Team.Type.Monsters || !Plugin.IsConstruct(unit)
                || Plugin.ConstructSummons == null) return;
            g.GetCardStatistics().IncrementStat(unit.GetSpawnerCard(), Plugin.ConstructSummonStat, 1);
            if (unit.IsAlive && !unit.IsDestroyed && Plugin.Has(g, "BinaryPrayerBeads"))
                unit.BuffDamage(ConstructAttackBonus(Plugin.ConstructSummons.GetCurrentValue(g.GetSaveManager().PreviewMode)));
        }
        internal static IEnumerator AfterReset(CharacterState replacement, ICoreGameManagers g)
        {
            if (replacement != null && replacement.IsAlive && !replacement.IsDestroyed
                && replacement.GetTeamType() == Team.Type.Monsters && Plugin.Has(g, "NirvanicWrath"))
                yield return Effects.Attack(replacement, g);
        }
    }
}
