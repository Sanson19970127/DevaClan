using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using Conductor.Extensions;
using Conductor.TrackedValues;
using Conductor.UI;
using TrainworksReloaded.Core;
using TrainworksReloaded.Core.Extensions;
using TrainworksReloaded.Core.Interfaces;
using TrainworksReloaded.Base;
using TrainworksReloaded.Base.Extensions;
using UnityEngine;
using UnityEngine.UI;

namespace DevaClan
{
    public sealed class StatusEffectKarmergy : StatusEffectState
    {
        int AttackPerStack(ICoreGameManagers g) => 10 + (Plugin.Has(g, "KarmicIncense") ? 5 : 0);
        public override void OnStacksAdded(CharacterState c, int n, CharacterState.AddStatusEffectParams p, ICoreGameManagers g)
        {
            c.BuffDamage(n * AttackPerStack(g), null, true);
            c.SetHealth(c.GetHP() + n * 10, c.GetMaxHP() + n * 10);
        }
        public override void OnStacksRemoved(CharacterState c, int n, ICoreGameManagers g)
        {
            c.DebuffDamage(n * AttackPerStack(g), null, true);
            int max = Math.Max(1, c.GetMaxHP() - n * 10);
            c.SetHealth(Math.Min(max, Math.Max(c.IsAlive ? 1 : 0, c.GetHP() - n * 10)), max);
        }
        public override int GetEffectMagnitude(int stacks = 1) => stacks * 10;
    }
    public sealed class RelicEffectDevaMarker : RelicEffectBase
    {
        public override PropDescriptions CreateEditorInspectorDescriptions() => new PropDescriptions();
    }

}
