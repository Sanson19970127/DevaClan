using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using Conductor.Extensions;
using Conductor.TrackedValues;
using Conductor.UI;
using TrainworksReloaded.Core;
using TrainworksReloaded.Core.Extensions;
using TrainworksReloaded.Core.Interfaces;
using TrainworksReloaded.Base;
using TrainworksReloaded.Base.Extensions;
using UnityEngine;
using UnityEngine.UI;

namespace DevaClan
{
    [HarmonyPatch(typeof(CardManager), nameof(CardManager.FireUnitTriggersForCardPlayed))]
    [HarmonyAfter("Conductor")]
    static class AbilityEvents
    {
        static IEnumerator Postfix(IEnumerator result, ICharacterManager characterManager, CardState playedCard, CharacterState characterThatActivatedAbility, int playedRoomIndex, AllGameManagers ___allGameManagers)
        {
            var g = ___allGameManagers.GetCoreManagers();
            while (result.MoveNext()) yield return result.Current;
            if (!ReferenceEquals(characterManager, g.GetMonsterManager())) yield break;
            if (Plugin.Is(playedCard, "SixRealms")) BattleMemory.Active.Discounts.Remove(playedCard);
            if (!playedCard.IsAnyAbility()) yield break;
            if (characterThatActivatedAbility != null && characterThatActivatedAbility.GetTeamType() != Team.Type.Monsters) yield break;
            var memory = BattleMemory.Active;
            foreach (var card in g.GetCardManager().GetHand())
                if (Plugin.Is(card, "SixRealms")) { memory.Discounts.TryGetValue(card, out int old); memory.Discounts[card] = old + 1; }
            g.GetCardManager().RefreshHandCards();
            if (characterThatActivatedAbility != null)
            {
                memory.Abilities++;
                yield return SingingBowl.AfterAbility(playedCard, characterThatActivatedAbility, Plugin.Has(g, "SingingBowl"));
                if (Plugin.Has(g, "PrayerWheel") && memory.Abilities % 3 == 0) g.GetCardManager().DrawCards(1);
                if (Plugin.Has(g, "InsightCircuit") && RandomManager.Range(0, 4, g.GetSaveManager().PreviewMode ? RngId.BattleTest : RngId.Battle) == 0)
                    characterThatActivatedAbility.RemoveStatusEffect("cooldown", 999, false);
            }
            else
            {
                // Conductor's Evoke handles unit abilities. Extend it to room abilities too.
                foreach (var c in Plugin.Floor(g.GetRoomManager().GetRoom(playedRoomIndex)))
                    yield return g.GetCombatManager().QueueAndRunTrigger(c, Conductor.Triggers.CharacterTriggers.Evoke);
            }
        }
    }
    [HarmonyPatch(typeof(CardState), nameof(CardState.GetCost))]
    static class SixRealmsCost
    {
        static void Postfix(CardState __instance, ref int __result)
        {
            if (Plugin.Is(__instance, "SixRealms") && BattleMemory.Active.Discounts.TryGetValue(__instance, out int n)) __result = Math.Max(0, __result - n);
        }
    }
}
