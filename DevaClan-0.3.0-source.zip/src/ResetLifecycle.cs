using System.Collections;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;

namespace DevaClan
{
    // CharacterState.OnSpawn is also used by the engine when a unit is
    // reconstructed by Reset. Vanilla summon triggers are intended for a
    // card played from hand, so suppress only the OnSpawn trigger while the
    // reset replacement is being created. Other spawn bookkeeping and
    // OnUnscaledSpawn remain vanilla.
    [HarmonyPatch(typeof(CombatManager), nameof(CombatManager.QueueAndRunTrigger))]
    static class SuppressSummonOnReset
    {
        static bool Prefix(CharacterState character, CharacterTriggerData.Trigger trigger)
        {
            return !(trigger == CharacterTriggerData.Trigger.OnSpawn
                && ResetLifecycle.IsResetReplacementActive);
        }
    }

    // A reset trigger can edit the transfer without knowing how replacement,
    // sacrifice, standby cards or spawn placement are implemented.
    internal sealed class ResetContext
    {
        internal readonly CharacterState Original;
        internal int Karma;
        internal CardState Equipment;
        internal KeyValuePair<string, int>[] PositiveStatuses = new KeyValuePair<string, int>[0];
        internal ResetContext(CharacterState original, int karma) { Original = original; Karma = karma; }
        internal void PreserveEquipment()
        {
            Equipment = Original.GetEquipment().FirstOrDefault(e => Plugin.Is(e, "SoulBackup"));
            if (Equipment == null) return;
            var positive = new List<CharacterState.StatusEffectStack>();
            Original.GetStatusEffects(ref positive);
            PositiveStatuses = positive.Where(s => s.Count > 0
                && s.State.GetDisplayCategory() == StatusEffectData.DisplayCategory.Positive
                && s.State.GetStatusId() != Plugin.KarmaId)
                .Select(s => new KeyValuePair<string, int>(s.State.GetStatusId(), s.Count)).ToArray();
        }
    }

    internal static class ResetLifecycle
    {
        // Scoped to the running coroutine; always removed even if it is disposed.
        static readonly Dictionary<CharacterState, ResetContext> contexts = new Dictionary<CharacterState, ResetContext>();
        internal static bool IsResetReplacementActive { get; private set; }
        internal static void Begin(ResetContext context) => contexts.Add(context.Original, context);
        internal static void End(CharacterState unit) { contexts.Remove(unit); IsResetReplacementActive = false; }
        internal static ResetContext Get(CharacterState unit) => unit != null && contexts.TryGetValue(unit, out var value) ? value : null;
        internal static void BeginReplacement() => IsResetReplacementActive = true;
    }

    public sealed class CardEffectDoubleResetKarmergy : DevaEffectBase
    {
        public override IEnumerator ApplyEffect(CardEffectState e, CardEffectParams p, ICoreGameManagers g, ISystemManagers sys)
        {
            var reset = ResetLifecycle.Get(p.selfTarget);
            if (reset != null) reset.Karma *= 2;
            yield break;
        }
    }

    public sealed class CardEffectPreserveResetStatuses : DevaEffectBase
    {
        public override IEnumerator ApplyEffect(CardEffectState e, CardEffectParams p, ICoreGameManagers g, ISystemManagers sys)
        {
            ResetLifecycle.Get(p.selfTarget)?.PreserveEquipment();
            yield break;
        }
    }
}
