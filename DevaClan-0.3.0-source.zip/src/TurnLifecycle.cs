using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using Conductor.Extensions;
using Conductor.TrackedValues;
using Conductor.UI;
using TrainworksReloaded.Core;
using TrainworksReloaded.Core.Extensions;
using TrainworksReloaded.Core.Interfaces;
using TrainworksReloaded.Base;
using TrainworksReloaded.Base.Extensions;
using UnityEngine;
using UnityEngine.UI;

namespace DevaClan
{
    [HarmonyPatch(typeof(CombatManager), "RunMonsterTurn")]
    static class TurnStart
    {
        static IEnumerator Postfix(IEnumerator result, bool isFirstTurn, AllGameManagers ___allGameManagers)
        {
            var g = ___allGameManagers.GetCoreManagers();
            var feastFloors = BalanceRules.ConsumeFeast();
            BattleMemory.Active.Karma.Clear();
            BattleMemory.Active.Relentless.Clear();
            foreach (var item in BattleMemory.Active.TurnSilence.ToArray())
            {
                var character = item.Key;
                if (character != null && !character.IsDestroyed && character.IsAlive)
                {
                    int current = character.GetStatusEffectStacks("silenced");
                    if (current > 0) character.RemoveStatusEffect("silenced", Math.Min(current, item.Value), false);
                }
            }
            BattleMemory.Active.TurnSilence.Clear();
            foreach(var c in BattleMemory.Active.Stasis) if(c != null && !c.IsDestroyed && c.IsAlive) c.RemoveStatusEffect("untouchable",1,false);
            BattleMemory.Active.Stasis.Clear();
            for (int i = 0; i < g.GetRoomManager().GetNumRooms(); ++i)
            {
                var units = Plugin.Floor(g.GetRoomManager().GetRoom(i), Team.Type.Monsters | Team.Type.Heroes);
                int retain = units.Where(c => c.GetTeamType() == Team.Type.Monsters && !c.HasStatusEffect("silenced")).Select(c => Plugin.Level(c, "MaraLiberation")).DefaultIfEmpty(0).Max();
                foreach (var c in units)
                {
                    int n = c.GetStatusEffectStacks(Plugin.KarmaId);
                    int keep = BalanceRules.RetainedKarmergy(n, c.GetTeamType() == Team.Type.Monsters, retain, feastFloors.Contains(i));
                    if (n > keep) c.RemoveStatusEffect(Plugin.KarmaId, n - keep, false);
                    if (TemporaryMemory.Contains(c)) yield return c.Sacrifice(null);
                }
            }
            if (isFirstTurn && Plugin.Has(g, "ReserveEnergy")) Plugin.Gain(g, 5);
            while (result.MoveNext()) yield return result.Current;
        }
    }
}
