# 天人氏族 0.3.0 平衡调整候选版

作者：sanson。适用于《怪物火车2》，支持英文和简体中文。

已按先重构后平衡的顺序完成：在独立的0.2.10重构版上，调整乐欲盛宴、移除同步矩阵、新增涅槃之怒与二进制念珠，补全衍生造物图鉴和五项中英文趣闻。原有0.2.9修复保留。

本版通过编译和自动检查，尚未执行游戏内实测。详细规则、占位美术和验收清单见BALANCE-030-NOTES.md，具体检查结果见VALIDATION-REPORT.json。

## 安装

关闭游戏，完整解压Windows包，运行Install.cmd。默认游戏目录为D:\SteamLibrary\steamapps\common\Monster Train 2，安装器会备份旧模组目录。

手动安装时，先移走旧DevaClan整个目录，再复制包中的BepInEx/plugins/DevaClan。不要合并保留旧JSON，也不要只更换DLL。请新开局测试；持有已移除同步矩阵的旧存档不保证兼容。

需要BepInEx 5、Trainworks Reloaded 0.7.20、Conductor 0.5.10。包内不包含游戏和这些依赖。本次未自动安装至游戏。

## 本版内容

- 乐欲盛宴：3费，友方业力2，所选楼层在下一次己方回合开始时完整保留业力一次。
- 涅槃之怒：友方重置成功后立即攻击。
- 二进制念珠：本场每召唤一次造物，本次召唤者获得+2攻击；计入本次，首次+2。
- 完美造物、巨大造物、防火墙造物加入图鉴；它们和两件新遗物均补全中英文趣闻。
- 共66个卡牌/能力定义、21个单位定义、11件遗物。

两件新遗物暂用现有占位美术，独立替换路径见ART-REPLACEMENT.csv。完美造物以一级作为图鉴代表。

## 源码与回退

源码编译见BUILD.md。核心机制位于src，数据位于json，图片位于textures。重构说明见REFACTOR-031-NOTES.md；旧版历史修复说明仅作参考。

独立0.2.10重构包仍保留，可与0.3.0分别测试。回退必须恢复整套旧目录。

## English

Version 0.3.0 is a candidate build: reset-trigger refactoring, Feast of Desire rebalance, Nirvanic Wrath and Binary Prayer Beads, token compendium entries and bilingual lore. Automated checks passed; Unity gameplay, full undo replay and old-save compatibility have not been verified. New relic art is placeholder artwork. Install the entire folder with the game closed, and test in a new run.
